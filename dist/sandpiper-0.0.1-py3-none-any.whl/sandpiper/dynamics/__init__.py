__version__='0.0.1'
from .dynamics import (
attach_trs_geometry,
infer_weights,
get_coastal_Markov,
BCDs_compute,
steady_state_transect,
compute_rBCD_transects
)
